my_list = [1, 2, 3, 4, 5]

output = ""
for item in my_list:
    output += str(item) + " "
    print(output)

print(output.strip())