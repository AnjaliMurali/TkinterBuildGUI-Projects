import random

subjects = ["Math","English","History","Geography","Science","Computer","Vernacular"]
lang = ["Spanish","French","Latin","Hindi","Dutch"]
sports = ["Football","Cricket","Tennis","Basketball","Hockey","Baseball","Swimming","Rowing"]
# hours = random.randint(4,8)

s1 = random.choice(subjects)
s2 = random.choice(subjects)
l1 = random.choice(lang)
l2 = random.choice(lang)
sport1 = random.choice(sports)
sport2 = random.choice(sports)

print("A good combination to be taught in school for 6 hours would be {},{},{},{},{},{}".format(s1,l1,sport1,s2,l2,sport2))
