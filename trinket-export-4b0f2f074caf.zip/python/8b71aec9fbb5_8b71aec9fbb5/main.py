fruits= ["mango","apples"]
print(fruits)
fruits.append("banana")
print(fruits)
fruits.remove("banana")
print(fruits)