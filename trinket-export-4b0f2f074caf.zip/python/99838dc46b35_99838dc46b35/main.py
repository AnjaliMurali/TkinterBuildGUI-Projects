import turtle

screen = turtle.Screen()
screen.setup(width=600, height=400)
#screen.tracer(0) 
screen.bgcolor("black")

rectCors1 = ((-20,10),(20,10),(20,-10),(-20,-10));
screen.register_shape('rectBrick',rectCors1);

bricks = []
colors = ["red", "orange", "yellow", "green", "blue"]
for row in range(5):  
    for x in range(-250, 300, 80):  
        brick = turtle.Turtle()
        brick.shape("rectBrick")
        brick.color(colors[row])  # Different colors for each row
        brick.penup()
        brick.speed(0)
        brick.setheading(90)
        brick.goto(x, 150 - (row * 30))
        bricks.append(brick)
