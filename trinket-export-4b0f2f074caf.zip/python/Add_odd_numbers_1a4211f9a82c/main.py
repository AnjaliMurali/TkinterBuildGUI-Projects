sum=0
x = int(input("Enter start value : "))
y=int(input("Enter end value : "))
for i in range(x,y+11,2):
  sum = sum+i;
print(sum)