while True:
  print("\n Calculator at work!\n")
  input1 = input('Enter a number or type STOP to stop the calculator ').strip()
  if input1.upper()=='STOP':
    break     
  elif not input1.isdigit():
    print('This is not a valid number.')
    continue
  else:
    number1 = int(input1)

  op = input('Enter an operator: +,-,*,/,% ')
  op = op.strip()

  input2 = input('Enter another number: ').strip()
  if not input2.isdigit():
    print('This is not a valid number.')
    continue
  else:
    number2 = int(input2)

  if op=='+':
    ans = number1+number2
  elif op=='-':
    ans = number1-number2
  elif op=='*':
    ans = number1*number2
  elif op=='/':
    ans = number1/number2
  elif op=='%':
    ans = number1%number2
  else:
    print('You did not enter a valid operation.')
  #print(number1,op,number2, '=', ans)
  #print(f"{number1} {op} {number2} = {ans}") 
  print("{}{}{}={}".format(number1,op,number2,ans))