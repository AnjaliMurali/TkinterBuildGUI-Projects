while True:
  print("\n Calculator at work!\n")
  input1 = input('Enter a number or type STOP to stop the calculator ')
  if input1=='STOP':
    break
  elif not input1.isdigit():
    print('This is not a valid number.')
    continue
  else:
    number1 = int(input1.strip())

  op = input('Enter an operator: +,-,*,/,% ')
  op = op.strip()

  input2 = input('Enter another number: ')
  if not input2.isdigit():
    print('This is not a valid number.')
    continue
  else:
    number2 = int(input2.strip())

  if op=='+':
    ans = number1+number2
  elif op=='-':
    ans = number1-number2
  elif op=='*':
    ans = number1*number2
  elif op=='/':
    ans = number1/number2
  elif op=='%':
    ans = number1%number2
  else:
    print('You did not enter a valid operation.')
  print(number1,op,number2,'=',ans)5
  