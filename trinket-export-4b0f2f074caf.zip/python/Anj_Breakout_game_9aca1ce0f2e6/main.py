'''Game Instructions:
Tap on the screen to begin the game.
Use left and right arrow keys for the paddle movement
'''

import turtle
import time

# Set up the screen
screen = turtle.Screen()
screen.setup(width=600, height=400)
screen.tracer(0) 
screen.bgcolor("black")

rectCors = ((-60,10),(60,10),(60,-10),(-60,-10));
screen.register_shape('rectangle',rectCors);

rectCors1 = ((-20,10),(20,10),(20,-10),(-20,-10));
screen.register_shape('rectBrick',rectCors1);


# Paddle
paddle = turtle.Turtle()
#paddle.shape("square")
paddle.shape('rectangle');
paddle.setheading(90)
paddle.color("gray")
paddle.penup()
paddle.speed(0)
paddle.goto(0, -180)
paddle_width = 120  # Paddle width in pixels

# Paddle movement
def paddle_left():
    x = paddle.xcor()
    if x - paddle_width // 2 > -300:  # Prevent going off-screen
        paddle.setx(x - 20)

def paddle_right():
    x = paddle.xcor()
    if x + paddle_width // 2 < 300:  # Prevent going off-screen
        paddle.setx(x + 20)

screen.listen()
screen.onkey(paddle_left, "Left")
screen.onkey(paddle_right, "Right")


# Bricks
bricks = []
colors = ["red", "orange", "yellow", "green", "blue"]
for row in range(5):  
    for x in range(-250, 300, 80):  
        brick = turtle.Turtle()
        brick.shape("rectBrick")
        brick.color(colors[row])  # Different colors for each row
        brick.penup()
        brick.speed(0)
        brick.setheading(90)
        brick.goto(x, 150 - (row * 30))
        bricks.append(brick)
        
# Ball
ball = turtle.Turtle()
ball.shape("circle")
ball.color("white")
ball.penup()
ball.speed(0)
ball.goto(0, 0)
ball.dx = 2
ball.dy = -2

# Score
score = 0
score_display = turtle.Turtle()
score_display.color("white")
score_display.penup()
score_display.hideturtle()
score_display.goto(0, 170)
score_display.write("Score: {}".format(score), align="center", font=("Courier", 16, "normal"))

# Game start flag
game_started = False

def start_game(x,y):
    global game_started
    game_started = True

screen.onclick(start_game)

while True:
  screen.update()
  time.sleep(0.01)
  if game_started:
    ball.setx(ball.xcor() + ball.dx)
    ball.sety(ball.ycor() + ball.dy)
     # Ball collision with walls
    if ball.xcor() > 290 or ball.xcor() < -290:  
        ball.dx *= -1
    if ball.ycor() > 190:  
          ball.dy *= -1
    if ball.ycor() < -190:  # Reset ball when it falls off the bottom
        ball.goto(0, 0)
        ball.dy *= -1
        game_started = False
        
    # Ball collision with paddle
     #distance can be used only if the turtles are of same shape. 
    if (paddle.xcor() - paddle_width/2 < ball.xcor() < paddle.xcor() + paddle_width/2
    and
    -170 < ball.ycor() < -160):
        ball.dy *= -1
        
    # Ball collision with bricks    
    for brick in bricks[:]:
        if abs(ball.xcor() - brick.xcor()) < 50 and abs(ball.ycor() - brick.ycor()) < 20:
        #if brick.distance(ball) < 10:
            ball.dy *= -1
            brick.hideturtle()  # Hide the brick visually
            bricks.remove(brick)
            score += 10
            #if different score to be increased for different colors: 
                #explaination : brick.color() does not return just a single string. It returns a tuple like this:(pencolor, fillcolor). To refer to pencolor we have to put[0].
            #if brick.color()[0] == "red":    
              #score += 10
            score_display.clear()
            score_display.write("Score: {}".format(score), align="center", font=("Courier", 16, "normal"))
            
    # Check for game over
    if not bricks:
        screen.bgcolor("black")
        paddle.hideturtle()
        ball.hideturtle()
        screen.update()
        print("You Win!")
        game_started = False
        #break