import random
import turtle

pen = turtle.Turtle()
paper = turtle.Screen()
pen.hideturtle()
pen.speed(100)
paper.bgcolor("black")
pen.color("white")
pen.penup()
pen.goto(-50,-150)
pen.left(90)
pen.pendown()
pen.forward(250)
pen.right(90)
pen.forward(100)
pen.right(90)
pen.forward(50)
pen.pensize(3)







def hangman():
    # List of words to guess
    words = ["python", "hangman", "developer", "algorithm", "jetlearn", "variable"]
    
    # Randomly choose a word
    word_to_guess = random.choice(words)
    
    # Create placeholders for the word
    guessed_word = ["_"] * len(word_to_guess)
    
    '''You may also use this method for creating the placeholders
    
    guessed_word = []
    for i in word_to_guess:
      guessed_word.append("_")'''
    
    max_attempts = 6  # Maximum attempts
    attempts = 0
    guessed_letters = []  # List to track guessed letters

    print ("Welcome to Hangman! Guess the word one letter at a time.")
    print "Word: ", " ".join(guessed_word)

    while attempts < max_attempts and "_" in guessed_word:
        guess = input("\nEnter a letter: ").lower()

        # Input validation
        if len(guess) != 1 or not guess.isalpha():
            print("Please enter a single valid letter.")
            continue
          
        # Check if letter has already been guessed
        if guess in guessed_letters:
            print ("You already guessed that letter. Try again.")
            continue

        guessed_letters.append(guess)
        
        
        # Check if guess is correct
        if guess in word_to_guess:
            print ("Good guess! '{}' is in the word.".format(guess))
            for i in range(len(word_to_guess)):
                if word_to_guess[i] == guess:
                    guessed_word[i] = guess
        else:
            attempts += 1
            print ("Wrong guess. You have {} attempts left.".format(max_attempts - attempts))
            if attempts == 1:
              #head
              pen.right(90)
              pen.circle(25)
            elif attempts ==2:
              #spine
              pen.penup()
              pen.goto(50,0)
              pen.setheading(270)
              pen.pendown()
              pen.forward(75)
            elif attempts ==3:
              #1 leg
              pen.setheading(240)
              pen.forward(50)
            elif attempts ==4:
              #2leg
              pen.penup()
              pen.goto(50,-75)
              pen.setheading(300)
              pen.pendown()
              pen.forward(50)
            elif attempts ==5:
              #1hand
              pen.penup()
              pen.goto(50,-20)
              pen.setheading(220)
              pen.pendown()
              pen.forward(50)
            else:
              #2hand
              pen.penup()
              pen.goto(50,-20)
              pen.setheading(320)
              pen.pendown()
              pen.forward(50)
              
            

        print "Word: ", " ".join(guessed_word)

    if "_" not in guessed_word:
        print ("Congratulations! You guessed the word '{}'.".format(word_to_guess))
    else:
        print ("Game Over! The word was '{}'. Better luck next time!".format(word_to_guess))

# Start the game
hangman()