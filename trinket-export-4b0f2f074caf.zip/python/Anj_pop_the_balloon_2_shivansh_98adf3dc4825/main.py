import turtle
import random
import time

dart = turtle.Turtle()
paper = turtle.Screen()

paper.setup(600,900)
paper.bgcolor("light blue")
paper.tracer(0)


dart.shape("triangle")
dart.penup()
dart.goto(0,-400)
dart.right(30)
dart.color("red")


def move_left():
  x = dart.xcor() - 30
  dart.setx(x)
def move_right():
  x = dart.xcor() + 30
  dart.setx(x)
  

paper.listen()
paper.onkey(move_left, "Left")
paper.onkey(move_right, "Right")

balloons = []

def spawn_balloon():
  balloon = turtle.Turtle()
  balloon.shape("circle")
  color_list = ["red","green","blue","yellow","purple"]
  c = random.choice(color_list)
  balloon.color(c)
  balloon.mycolor = c
  balloon.penup()
  balloon.goto(random.randint(-250,250),400)
  
  if c == "red":
    balloon.speed=6
  elif c == "purple":
    balloon.speed=5
  elif c == "blue":
    balloon.speed=4
  elif c == "green":
    balloon.speed=3
  elif c == "yellow":
   balloon.speed=2
  
  if random.random() < 0.2:  # 20% chance to be a bomb
        balloon.color("black")
        balloon.speed = random.randint(1,10)
        balloon.is_bomb = True
  else:
      balloon.is_bomb = False
      
  balloons.append(balloon)
  
# Game variables
game_speed = 0.2
difficulty_increase = 0.01
spawn_interval = 2
last_spawn_time = time.time()

# Score display
score = 0
score_display = turtle.Turtle()
score_display.hideturtle()
score_display.penup()
score_display.goto(200, -430)
score_display.color("black")
score_display.write("Score: {}".format(score), font=("Arial", 16, "normal"))

def updatescore():
  global score
  score_display.clear()
  score_display.write("Score: " + str(score), font=("Arial", 16, "normal"))
  
def game_over():
    global running
    running = False
    paper.tracer(0)
    score_display.goto(0, -50)
    score_display.clear()
    score_display.write("Final Score: " + str(score), align="center", font=("Arial", 20, "bold"))
    game_over_display = turtle.Turtle()
    game_over_display.hideturtle()
    game_over_display.color("red")
    game_over_display.write("GAME OVER", align="center", font=("Arial", 36, "bold"))
    paper.update()
    time.sleep(2)
    paper.bye()

start = time.time()
running = True
while running :
  
  paper.update()
  current_time = time.time()
  if current_time-start >= 100:
    #paper.bgcolor("black")
    #running = False
    game_over()
  # Spawn balloons at intervals
  if current_time - last_spawn_time > spawn_interval:
      spawn_balloon()
      last_spawn_time = current_time
  
  for balloon in balloons[:]:
    balloon.sety(balloon.ycor() - balloon.speed)
    if balloon.ycor() < -450:
      balloons.remove(balloon)
      balloon.hideturtle()
  # Check for collision with dart
    if dart.distance(balloon) < 30:
        if balloon.is_bomb:
              game_over()
        if balloon.mycolor == "red":
          score += 10
          updatescore()
        balloons.remove(balloon)
        balloon.hideturtle()
        
   # Increase difficulty over time
  game_speed = max(0.005, game_speed - difficulty_increase)  # Prevent negative game_speed
  spawn_interval = max(0.5, spawn_interval - 0.0005)         # Prevent too-frequent spawns
  
  time.sleep(game_speed)
  
  
  

























