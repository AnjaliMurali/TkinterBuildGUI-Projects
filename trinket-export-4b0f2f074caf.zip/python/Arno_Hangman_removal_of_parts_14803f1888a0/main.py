import random
import turtle
t=turtle.Turtle()
s=turtle.Screen()
t.speed(100)
t.goto(-25,0)
t.goto(25,0)
t.goto(0,0)
t.goto(0,100)
t.goto(-40,100)
t.left(-90)
t.forward(25)
#head
t.setheading(180)
t.circle(10)
#body
t.setheading(270)
t.penup()
t.forward(20)
t.pendown()
t.forward(30)
#left leg
t.setheading(305)
t.forward(20)
t.setheading(125)
t.forward(20)
#right leg
t.setheading(230)
t.forward(20)
t.setheading(50)
t.forward(20)
t.setheading(90)
#left arm
t.forward(16)
t.setheading(35)
t.forward(20)
t.setheading(215)
t.forward(20)
#right arm
t.setheading(150)
t.forward(20)
t.hideturtle()

attempts=0
I=["fortnite","backspace","ferrari","calculator","microbit","instructions","impossible","jetlearn2","redeem","favourites"]
Word=random.choice(I)
print("Welcome to HANGMAN EXTREME, guess the word.")
G=["_ "]*len(Word)
print(" ".join(G))
while "_ " in G:
  A=input("Type your guess(enter one letter at a time please)")
  if A in Word:
    for i in range(len(Word)):
      if Word[i]==A:
        G[i]=A
  else:
    print("Worng Guess")
    attempts+=1
    if attempts==1:
      t.clear()
      t.setheading(0)
      t.penup()
      t.goto(-25,0)
      t.pendown()
      t.goto(25,0)
      t.goto(0,0)
      t.goto(0,100)
      t.goto(-40,100)
      t.pendown()
      t.left(-90)
      t.forward(25)
      #head
      t.setheading(180)
      t.circle(10)
      #body
      t.setheading(270)
      t.penup()
      t.forward(20)
      t.pendown()
      t.forward(30)
      #left leg
      t.setheading(305)
      t.forward(20)
      t.setheading(125)
      t.forward(20)
      #right leg
      t.setheading(230)
      t.forward(20)
      t.setheading(50)
      t.forward(20)
      t.setheading(90)
      #left arm
      t.forward(16)
      t.setheading(35)
      t.forward(20)
      t.setheading(215)
      t.forward(20)
    if attempts==2:
      t.clear()
      t.setheading(0)
      t.penup()
      t.goto(-25,0)
      t.pendown()
      t.goto(25,0)
      t.goto(0,0)
      t.goto(0,100)
      t.goto(-40,100)
      t.pendown()
      t.left(-90)
      t.forward(25)
      #head
      t.setheading(180)
      t.circle(10)
      #body
      t.setheading(270)
      t.penup()
      t.forward(20)
      t.pendown()
      t.forward(30)
      #left leg
      t.setheading(305)
      t.forward(20)
      t.setheading(125)
      t.forward(20)
      #right leg
      t.setheading(230)
      t.forward(20)
      t.setheading(50)
      t.forward(20)
      t.setheading(90)
    if attempts==3:
      t.clear()
      t.setheading(0)
      t.penup()
      t.goto(-25,0)
      t.pendown()
      t.goto(25,0)
      t.goto(0,0)
      t.goto(0,100)
      t.goto(-40,100)
      t.pendown()
      t.left(-90)
      t.forward(25)
      #head
      t.setheading(180)
      t.circle(10)
      #body
      t.setheading(270)
      t.penup()
      t.forward(20)
      t.pendown()
      t.forward(30)
      #left leg
      t.setheading(305)
      t.forward(20)
      t.setheading(125)
      t.forward(20)
    if attempts==4:
      t.clear()
      t.setheading(0)
      t.penup()
      t.goto(-25,0)
      t.pendown()
      t.goto(25,0)
      t.goto(0,0)
      t.goto(0,100)
      t.goto(-40,100)
      t.pendown()
      t.left(-90)
      t.forward(25)
      #head
      t.setheading(180)
      t.circle(10)
      #body
      t.setheading(270)
      t.penup()
      t.forward(20)
      t.pendown()
      t.forward(30)
    if attempts==5:
      t.clear()
      t.setheading(0)
      t.penup()
      t.goto(-25,0)
      t.pendown()
      t.goto(25,0)
      t.goto(0,0)
      t.goto(0,100)
      t.goto(-40,100)
      t.pendown()
      t.left(-90)
      t.forward(25)
      #head
      t.setheading(180)
      t.circle(10)
    if attempts==6:
      t.clear()
      t.setheading(0)
      t.penup()
      t.goto(-25,0)
      t.pendown()
      t.goto(25,0)
      t.goto(0,0)
      t.goto(0,100)
      t.goto(-40,100)
      t.pendown()
      t.left(-90)
      t.forward(25)
  print(" _".join(G))
  if attempts ==6:
    print("You lost")
    break
if "_ " not in G:
    print("you guessed the word, Congratulations")