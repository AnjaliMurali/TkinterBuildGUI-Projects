
import os, time

question = input("What operation do you want to use \n1. Addition + \n2. Subtraction - \n3. Multiplication x \n4. Division /")




if question == "1" or question ==  "Addition":
  num1 = float(input("Enter the first number "))
  num2 = float(input("Enter the second number "))
  total = num1 + num2
  print("{} + {} = {} ".format(num1,num2,total))
elif question == "2" or question == "Subtraction":
  num1 = float(input("Enter the first number "))
  num2 = float(input("Enter the second number "))
  total = num1 - num2
  print("{} - {} = {} ".format(num1,num2,total))
elif question == "3" or question == "Multiplication":
  num1 = float(input("Enter the first number "))
  num2 = float(input("Enter the second number "))
  total = num1 * num2
  print("{} x {} = {} ".format(num1,num2,total))
elif question == "4" or question == "Division":
  num1 = float(input("Enter the first number "))
  num2 = float(input("Enter the second number "))
  total = num1 / num2
  print("{} ÷ {} = {} ".format(num1,num2,total))

  
