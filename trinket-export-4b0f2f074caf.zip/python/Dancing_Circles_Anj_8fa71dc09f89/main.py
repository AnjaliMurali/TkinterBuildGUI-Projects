import turtle
import random
import time

pen = turtle.Turtle()
paper = turtle.Screen()

pen.speed(100)
paper.bgcolor("black")
def draw():
  x = random.randint(-150,150)
  y = random.randint(-150,150)
  
  r = random.randint(0,255)
  b = random.randint(0,255)
  g = random.randint(0,255)
  pen.fillcolor(r,b,g)
  
  pen.begin_fill()
  size = random.randint(20,100)
  pen.penup()
  pen.goto(x,y)
  
  pen.circle(size)
  #pen.pendown()
  pen.end_fill()
  pen.penup()
delay = 0.8
start_time = time.time()
for i in range(5):
  draw()
  time.sleep(delay)
  pen.clear()
  delay = max(0.01, delay - 0.03)
end_time = time.time()
elapsed_time = round(end_time - start_time,2)
pen.penup()
pen.goto(0, 0)  # Center position
pen.color("white")
pen.write(
    "Total animation time: {} seconds".format(elapsed_time),
    align="center",
    font=("Arial", 16, "bold")
)
pen.hideturtle()
  
