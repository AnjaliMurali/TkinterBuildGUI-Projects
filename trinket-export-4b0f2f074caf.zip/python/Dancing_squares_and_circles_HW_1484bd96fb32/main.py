import turtle
import random
import time

# Set up the turtle and screen
turtle.speed(0)
sc = turtle.Screen()
sc.bgcolor("black")

# Define a function to draw a dancing circle

def draw_circle():
    # Choose a random position for the circle
    turtle.penup()
    turtle.goto(random.randint(-200, 200), random.randint(-200, 200))

    # Choose a random color for the circle
    turtle.color(
        random.randint(0, 255),
        random.randint(0, 255),
        random.randint(0, 255),
    )

    # Draw the circle
    turtle.begin_fill()
    turtle.pendown()
    turtle.circle(random.randint(50, 70))
    turtle.penup()
    turtle.end_fill()
    turtle.hideturtle()

def draw_square():
    # Choose a random position for the circle
    turtle.penup()
    turtle.goto(random.randint(-200, 200), random.randint(-200, 200))

    # Choose a random color for the circle
    turtle.color(
        random.randint(0, 255),
        random.randint(0, 255),
        random.randint(0, 255),
    )

    # Draw the circle
    
    turtle.pendown()
    turtle.begin_fill()
    side = random.randint(50,200)
    for i in range(4):
      turtle.forward(side)
      turtle.right(90)
    turtle.end_fill()
    turtle.penup()
    turtle.hideturtle()

# Initial delay in seconds
delay = 0.8

# Track the start time
start_time = time.time()

# Loop to draw circles with decreasing delay
for i in range(50):
    shape = random.randint(1,2)
    if shape == 1 :
      draw_square()
    else:
      draw_circle()
    time.sleep(delay)
    turtle.clear()
    delay = max(0.01, delay - 0.05)  # Ensure delay doesn't go below 0.01

# Track the end time
end_time = time.time()

# Calculate the total elapsed time
elapsed_time = round(end_time - start_time,2)

# Display the elapsed time on the screen
turtle.penup()
turtle.goto(0, 0)  # Center position
turtle.color("white")
turtle.write(
    "Total animation time: {} seconds".format(elapsed_time),
    align="center",
    font=("Arial", 16, "bold")
)