tasks = []

print("\n--- To-Do List Menu ---")
print("1. View tasks")
print("2. Add a task")
print("3. Remove a task")
print("4. Exit")
print("5. Edit a task")

choice = input("Choose an option (1-5): ")
if choice == "1":
    print(tasks)
    
if choice == "2":