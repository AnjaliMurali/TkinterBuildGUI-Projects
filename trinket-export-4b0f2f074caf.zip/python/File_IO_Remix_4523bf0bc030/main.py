# Open file in write mode
file = open("example.txt", "w")

# Write to the file
file.write("Hello, World!\n")
file.write("This is a sample file.")

# Close the file
file.close()

# Open file in read mode
file = open("example.txt", "r")

# Read the entire content of the file
content = file.read()
print("File Content:\n" + content)

# Close the file
file.close()

print("-"*40)

#Reading line by line
file = open("example.txt", "r")
print(file.readline())
file.close()

print("-"*40)

#Appending to a File
file = open("example.txt", "a")
file.write("\nThis line was appended!")
file.close()

'''with statement'''

# Writing using 'with'
with open("data.txt", "w") as file:
    file.write("Line 1\n")

# Appending to a file
with open("data.txt", "a") as file:
    file.write("Line 2\n")

# Reading using 'with'
with open("data.txt", "r") as file:
    print(file.read())
