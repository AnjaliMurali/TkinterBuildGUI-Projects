import turtle
import random
pen = turtle.Turtle()
paper = turtle.Screen()

pen.speed(180)

paper.bgcolor("#00000")

for i in range (10):
  x = random.randint(-200,200)
  y = random.randint(-200,200)
  r = random.randint(0,255)
  g = random.randint(0,255)
  b = random.randint(0,255)
  pen.color(r,g,b)
  pen.penup()
  pen.goto(x,y)
  pen.pendown()
  #for i in range (84):
  for i in range (36):
    l = random.randint(15,60)
    pen.forward(l)
    pen.backward(l)
    #pen.left(17)
    pen.left(10)

  