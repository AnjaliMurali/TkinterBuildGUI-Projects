import turtle,random,time
paper=turtle.Screen()
pen=turtle.Turtle()
for i in range(1000000):
  red=random.randint(0,255)
  green=random.randint(0,255)
  blue=random.randint(0,255)
  paper.bgcolor((red,green,blue))
  time.sleep(0.1)
  pen.color(blue,red,green)
  size=random.randint(10,1000)
  pen.dot(size)