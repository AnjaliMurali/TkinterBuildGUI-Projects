# Convert cups to grams
def cups_to_grams(cups, conversion_rate):
    return cups * conversion_rate

# Convert tablespoons to teaspoons
def tablespoons_to_teaspoons(tablespoons):
    return tablespoons * 3  # 1 tablespoon = 3 teaspoons

# Convert grams to cups
def grams_to_cups(grams, conversion_rate):
    return grams / conversion_rate
    
def metres_to_feet(m):
    return m*3.28  #1m=3.28feet
    
def inches_to_cm(i):
    return i*2.54 #1inch=2.54cm


def length_converter():
  print("\nWelcome to the Length Converter!")
  while True:
    print("\nChoose an option:")
    print("1. Convert metres_to_feet")
    print("2. Convert inches_to_cm")
    print("3. Exit")
    
    choice = input("Enter your choice (1-3): ")

    if choice == "1":
      m = float(input("enter the number in metres : "))
      result = metres_to_feet(m)
      print("Result: {:.2f} feet".format(result))
      
    elif choice == "2":
      m = float(input("enter the number in inches : "))
      
      result = inches_to_cm(m)
      print("Result: {:.2f} cm".format(result))
      
    elif choice == "3":
      print("Thank you for using the Length Converter. Goodbye!")
      break
        
    else:
      print("Invalid choice. Please try again.")
      
# Main program
def recipe_converter():
    print("\nWelcome to the Recipe Converter!")
    
    while True:
        print("\nChoose an option:")
        print("1. Convert cups to grams")
        print("2. Convert tablespoons to teaspoons")
        print("3. Convert grams to cups")
        print("4. Exit")
        
        choice = input("Enter your choice (1-4): ")

        if choice == "1":
            cups = float(input("Enter the number of cups: "))
            conversion_rate = float(input("Enter the grams per cup for the ingredient: "))
            result = cups_to_grams(cups, conversion_rate)
            print("Result: {:.2f} grams".format(result))
        
        elif choice == "2":
            tablespoons = float(input("Enter the number of tablespoons: "))
            result = tablespoons_to_teaspoons(tablespoons)
            print("Result: {:.2f} teaspoons".format(result))
        
        elif choice == "3":
            grams = float(input("Enter the number of grams: "))
            conversion_rate = float(input("Enter the grams per cup for the ingredient: "))
            result = grams_to_cups(grams, conversion_rate)
            print("Result: {:.2f} cups".format(result))
        
        elif choice == "4":
            print("Thank you for using the Recipe Converter. Goodbye!")
            break
        
        else:
            print("Invalid choice. Please try again.")
            
            

# Run the program
print("Hello.. Welcome to the converters")
print("1. Recipe converter")
print("2. Length converter")
c = int(input("choose your option? "))
if c==1:
  recipe_converter()
elif c==2:
  length_converter()
else:
  print("Wrong choice, try again! ")