import turtle
import random

t = turtle.Turtle()
t.shape("turtle")
s = turtle.Screen()
guess = 0



while True: 
  
  num1 = random.randint(1, 10)
  num2 = random.randint(1, 10)
  ans = num1 * num2
  while (guess != ans):
    t.reset()
    guess = int(input("What is " + str(num1) + " * " + str(num2) + " ? "))
    print(guess)
   
    if (guess == ans):
      t.write("Correct!!")
      print("Correct!")
      t.penup()
      t.forward(10000)
      t.pendown()
    elif (guess != ans):
      print("Incorrect! Try again")
      t.goto(-100, 0)
      t.write("Incorrect! Try again!", font=("Arial", 20,"normal"))
      t.penup()
      t.forward(10000)
      t.pendown()
  t.hideturtle()

s.mainloop()
