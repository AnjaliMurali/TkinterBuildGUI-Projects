import random
answer = random.randint(1,100)
#attempts = 0
while True: 
  guess = int(input("Guess the number between 1 and 100: "))
  if(guess == answer):
    print("Correct!!!")
    break
  elif(guess < answer ):
    print("That's a small number")
    #attempts = attempts+1
  elif(guess > answer ):
    print("That's a big number")
    #attempts = attempts+1
  else:
    print("its a number....")
    attempts = attempts+1
#print("No. of attempts taken : " + str(attempts))

  
