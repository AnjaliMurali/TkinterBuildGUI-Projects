grid=[]
import random
def grid_Strt():
  for i in range(5):
    row=[]
    for j in range(5):
      row.append("-")
    grid.append(row)
  return grid
def trsr_pos():
  row=random.randint(0,4)
  colum=random.randint(0,4)
  return row,colum
  
def give_hint(treasure_row, treasure_col, guess_row, guess_col):
    if guess_row < treasure_row:
        return "Move down"
    elif guess_row > treasure_row:
        return "Move up"
    elif guess_col < treasure_col:
        return "Move right"
    elif guess_col > treasure_col:
        return "Move left"
    else:
      return "Congratulations! You found the treasure!"  

print("Welcome To The Treasure Hunting Game (TTHG)")
grid=grid_Strt()
tries=0
trsrRow,trsrColum=trsr_pos()
print(trsrRow,trsrColum)
while True:
  tries=tries+1
  for l in grid:
    print(" ".join(l))
  
  try:
    plr_Row=int(input("Please Select A Row To Guess (1-5):"))-1
    plr_Colum=int(input("Please Select A Colum To Guess (1-5):"))-1
    
    if plr_Row not in range(1,5) or plr_Colum not in range(1,5):
            raise ValueError
  except (ValueError, IndexError):
    print("Please Enter A Number From 1–5.")
    continue
  
  if plr_Row==trsrRow and plr_Colum==trsrColum:
    print("You Won! :) Tries="+str(tries))
  else:
    print("Incorrect, Go ")
    grid[plr_Row][plr_Colum]="O"
    hint = give_hint(trsrRow, trsrColum, plr_Row, plr_Colum)
    print("Hint: {}".format(hint))