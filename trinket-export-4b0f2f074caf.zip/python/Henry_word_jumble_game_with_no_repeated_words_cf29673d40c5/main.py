while True:
  import random
  def word_jumbler(rwg):
    letterlist=list(rwg)
    random.shuffle(letterlist)
    return ''.join(letterlist)
  def hint_getter(rwg):
    letter1=list(rwg)
    return letter1[0]
  elist=["time","kind","four","blue","weak","real","kiln","each","join","jump"]
  mlist=["orange","nuclear","printer","grumble","noodle","deafen","hungry","rocket","wooden","bumble"]
  hlist=["pineapple","pavement","campfire","weekend","absolute","halloween","computer","enormous","envelope","christmas"]
  print("Word Jumbler Dejumbler")
  while True:
    blacklist=[]
    level=input("Select Difficulty: Easy(e)/Medium(m)/Hard(h)")
    if level=="e":
      wordlist=elist
      break
    elif level=="m":
      wordlist=mlist
      break
    elif level=="h":
      wordlist=hlist
      break
    else:
      print("Please Enter A Valid Difficulty (e/m/h)")
      continue
  score=0
  question=1
  while(question<6):
    blcheck=0
    rwg=random.choice(wordlist)
    jword=word_jumbler(rwg)
    for m in blacklist:
      if m==rwg:
        blcheck=1
        break
    if blcheck==1:
      continue
    print("Q"+str(question)+"/5:\nGuess The Jumbled Word: "+jword)
    question=question+1
    hinty=input("Do You Want A Hint? (y/n)")
    if hinty=="y":
      hint_ans=hint_getter(rwg)
      print("The First Letter Of The Word Is: "+hint_ans)
    playerGuess=input("Answer:")
    if playerGuess==rwg:
      score=score+1
      print("Correct!")
    else:
      print("Wrong, The Correct Answer Was: "+rwg)
    blacklist.append(rwg)
  blacklist=[]
  if score<3:
    again=input("You Failed, Score "+str(score)+"/5. Play Again? (y/n):")
    if again=="y":
      continue
    elif again=="n":
      break
  if score>=3:
    again=input("You Won, Score "+str(score)+"/5. Play Again? (y/n):")
    if again=="y":
      continue
    elif again=="n":
      break