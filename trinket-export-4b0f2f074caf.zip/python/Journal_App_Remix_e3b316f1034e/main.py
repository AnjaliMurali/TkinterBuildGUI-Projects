from datetime import datetime

def add_entry():
    entry = input("Write your journal entry: ")
    with open("journal.txt", "a") as file:
        date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        file.write("[{}] {}\n".format(date, entry))
    print "Entry saved!"

def view_entries():
    with open("journal.txt", "r") as file:
        print("\n--- Your Journal Entries ---")
        index = 0
        for line in file:
            print("{}. {}".format(index, line.strip()))
            index += 1
            
def delete_entry():
    line_to_delete = int(raw_input("Enter the line number of the entry to delete: "))
    
    with open("journal.txt", "r") as file:
        lines = file.readlines()
    
    if line_to_delete < 0 or line_to_delete >= len(lines):
        print "Invalid line number."
        return

    with open("journal.txt", "w") as file:
        index = 0
        for line in lines:
            if index != line_to_delete:
                file.write(line)
            index += 1

    print "Entry deleted."

while True:
    print(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    print "\n--- Journal App ---"
    print "1. Add Entry"
    print "2. View Entries"
    print "3. Exit"
    print "4. Delete Entry"
    choice = input("Choose an option: ")
        
    if choice == "1":
        add_entry()
    elif choice == "2":
        view_entries()
    elif choice == "3":
        print "Goodbye!"
        break
    elif choice == "4":
      delete_entry()
    else:
        print "Invalid choice. Please try again."