import random
import turtle
import sys
import time

t = turtle.Turtle()
t.shape('turtle')
t.color("green")

s = turtle.Screen()

t1 = turtle.Turtle()
t1.shape("square")
t1.color("red")
t1.penup()
x = random.randint(-200,200)
y = random.randint(-200,200)
t1.goto(x,y)

#d = int(input("Enter the steps you want your turtle to move: "))
#print(d)
def up():
  t.setheading(90)
  check_collision()

def left():
  t.setheading(180)
  check_collision()

def down():
  t.setheading(270)
  check_collision()

def right():
  t.setheading(0)
  check_collision()

def mov():
  t.forward(5)
  check_collision()

#def change():
  #d = int(input("Enter the steps you want your turtle to move: "))
  #print(d)

s.listen()
#s.onkeypress(change,'c')
s.onkey(mov,"space")
s.onkey(up,'Up')
s.onkey(down,'Down')
s.onkey(right,'Right')
s.onkey(left,'Left')

def check_collision():
  if t.distance(t1) < 20:  # 20 is the collision distance threshold
      print("You win!")
      #s.bye() # Closes the canvas
      t1.hideturtle()
      t.clear()
      t.penup()
      t.goto(0,0)
      t.write("You win!", align="center", font=("Arial", 24, "bold"))
      time.sleep(5)
      exit()
    

  
s.mainloop()
    

  

