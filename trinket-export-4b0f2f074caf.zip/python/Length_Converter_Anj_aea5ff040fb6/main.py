def metres_to_feet(m):
    return m*3.28  #1m=3.28feet
    
def inches_to_cm(i):
    return i*2.54 #1inch=2.54cm


def length_converter():
  print("\nWelcome to the Length Converter!")
  while True:
    print("\nChoose an option:")
    print("1. Convert metres_to_feet")
    print("2. Convert inches_to_cm")
    print("3. Exit")
    
    choice = input("Enter your choice (1-3): ")

    if choice == "1":
      m = float(input("enter the number in metres : "))
      result = metres_to_feet(m)
      print("Result: {:.2f} feet".format(result))
      
    elif choice == "2":
      m = float(input("enter the number in inches : "))
      
      result = inches_to_cm(m)
      print("Result: {:.2f} cm".format(result))
      
    elif choice == "3":
      print("Thank you for using the Length Converter. Goodbye!")
      break
        
    else:
      print("Invalid choice. Please try again.")
      
length_converter()