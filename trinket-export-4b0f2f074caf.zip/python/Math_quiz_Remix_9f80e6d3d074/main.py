import random
num1 = random.randint(1,10)
num2 = random.randint(1,11)
ans = num1 * num2
eq = 0
while(eq!=ans):
  eq = int(input("What is " + str(num1) + "*"+ str(num2) + "?"))
  
  if(eq == ans):
    print ("Well done! :]")
    
  else:
    print("Oops! Try again! :o")