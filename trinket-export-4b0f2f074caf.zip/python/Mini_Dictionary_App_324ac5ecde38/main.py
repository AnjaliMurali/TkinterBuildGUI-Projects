"""
#conduct this activity before making the app
my_dict = {"apple": "a fruit", "book": "a set of written or printed pages"}
my_dict["car"] = "a vehicle" #adding a new key value pair
my_dict["apple"] = "a sweet fruit" #updating
del my_dict["book"] #deleting
my_dict.pop("car") #removing
print(my_dict["apple"])  # Output: a sweet fruit
#check if a key exists
if "apple" in my_dict:
    print("Key exists!")

"""

dictionary = {}

while True:
    print("\nMini Dictionary App")
    print("1. Add/Update a word")
    print("2. Retrieve a word's definition")
    print("3. Delete a word")
    print("4. View all words")
    print("5. Exit")
    print("6. Check for a word")
    print("7. Check how many words are there in the dictionary")
    print("8. Clear all words from the dictionary")

    choice = input("Choose an option (1-5): ")

    if choice == "1":
        word = input("Enter the word: ").strip()
        definition = input("Enter the definition: ").strip()
        dictionary[word] = definition
        print("Word '{}' added/updated successfully!".format(word))

    elif choice == "2":
        word = input("Enter the word to retrieve: ").strip()
        if word in dictionary:
            print("{}: {}".format(word, dictionary[word]))
        else:
            print("The word '{}' is not in the dictionary.".format(word))

    elif choice == "3":
        word = input("Enter the word to delete: ").strip()
        if word in dictionary:
            del dictionary[word]
            print("The word '{}' has been deleted.".format(word))
        else:
            print("The word '{}' is not in the dictionary.".format(word))

    elif choice == "4":
        if dictionary:
            print("\nWords in the dictionary:")
            for word in dictionary:
                print("{}: {}".format(word, dictionary[word]))
        else:
            print("The dictionary is empty.")

    elif choice == "5":
        print("Exiting the Mini Dictionary App. Goodbye!")
        break
      
    elif choice == "6":
      w = input("Enter the word you are looking for :")
      if w in dictionary:
        print("Yes, {} is available in the dictionary".format(w))
      else:
        print("No, {} is not available in the dictionary".format(w))
      
    elif choice == "7":
      num=0
      for w in dictionary:
        num+=1
      print("There are {} words in the dictionary".format(num))
    
    elif choice == "8":
      for w in dictionary:
        del dictionary[w]
      print(dictionary)
      

    else:
        print("Invalid choice. Please try again.")