x = int(input("Enter the number"))
for i in range(10):
  ans = x*i
  print(str(x) + " * " + str(i) + " = " + str(ans) )