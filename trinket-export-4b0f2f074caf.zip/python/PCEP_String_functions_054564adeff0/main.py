word = """
This 
is 
an example
of multiple lines
"""
print(word)
print(len(word))

w = "python is 2 awesome"
print(w.lower())
print(w.upper())
print(w.title())
print(w.swapcase())
print(w.capitalize())
print(w.count("s"))
print(w.find("is"))

name = "Alice"
age = 25

message = "My name is {} and I am {} years old.".format(name, age)

print(message)

"""
In Python, both find() and index() are used to search for a substring inside a string. The main difference is what happens when the substring is not found.

| Method    | If substring is found        | If substring is not found |
| --------- | ---------------------------- | ------------------------- |
| `find()`  | Returns the position (index) | Returns `-1`              |
| `index()` | Returns the position (index) | Raises a `ValueError`     |

"""

text = "Hello World"
print(text.find("World"))
print(text.index("World"))


text = "Hello World"
print(text.find("Python"))


#text = "Hello World"
#print(text.index("Python"))  #Output: ValueError: substring not found

#Split by space
text = "Python is easy"
words = text.split()
print(words)

#split by comma
text = "apple,banana,mango"
fruits = text.split(",")
print(fruits)


#join with space
words = ["Python", "is", "easy"]
sentence = " ".join(words)
print(sentence)

#join with *(you can replace * with any symbol or letter or number of your choice)
words = ["Python", "is", "easy"]
sentence = "*".join(words)
print(sentence)