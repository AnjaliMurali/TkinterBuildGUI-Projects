import random
numbers=["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"]
lowercase=["q","w","e","r","t","y","u","i","o","p","a","s","d","f","g","h","j","k","l","z","x","c","v","b","n","m"]
uppercase=["Q","W","E","R","T","Y","U","I","O","P","A","S","D","F","G","H","J","K","L","Z","X","C","V","B","N","M"]
special=["!","@","#","$","%","^","&","*","(",")"]
order=[]
output = ""
x=1

while True:
  order=[]
  output = ""
  n1 = random.choice(numbers)
  n2 = random.choice(numbers)
  l1 = random.choice(lowercase)
  l2 = random.choice(lowercase)
  u1 = random.choice(uppercase)
  u2 = random.choice(uppercase)
  s1 = random.choice(special)
  s2 = random.choice(special)
  
  
  order.append(n1)
  order.append(n2)
  order.append(l1)
  order.append(l2)
  order.append(u1)
  order.append(u2)
  order.append(s1)
  order.append(s2)
  random.shuffle(order)
  for i in order:
    output += str(i) +""
    
  
  print("Your password is: " + output)
  n = input("Do you want another password Yes/No")
  if(n=="Yes"):
    output = ""
  else:
    exit()
