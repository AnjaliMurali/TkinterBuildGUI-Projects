import turtle,random,time
screen = turtle.Screen()
screen.bgcolor("skyblue")
dart = turtle.Turtle()
dart.shape("Triangle")
dart.penup()
dart.color("red")
dart.setheading(90)
dart.goto(0,-150)
screen.tracer(0)  # turn off auto update for smooth animation
balloonlist = []
last_spawn_time = time.time()
running = True
score = 0

# Score display
score = 0
score_display = turtle.Turtle()
score_display.hideturtle()
score_display.penup()
score_display.goto(-180, 180)
score_display.color("black")
score_display.write("Score: {}".format(score), font=("Arial", 16, "normal"))

def move_left():
    x = dart.xcor() -10
    if x > -190:
        dart.setx(x)


def move_right():
    x = dart.xcor() + 10
    if x < 190:
        dart.setx(x)

def spawn_balloon():
    balloon = turtle.Turtle()
    balloon.penup()
    balloon.shape("circle")
    balloon.color(random.choice(["red", "green", "blue", "yellow"]))
    balloon.goto(random.randint(-150, 150), random.randint(150,200))
    balloon.speed = random.randint(1, 3)  
    if random.random() < 0.2:  # 20% chance to be a bomb
        balloon.color("black")
        balloon.is_bomb = True
    else:
        balloon.is_bomb = False
    balloonlist.append(balloon)
    
def update_score(points):
    global score
    score += points
    score_display.clear()
    score_display.write("Score: {}".format(score), font=("Arial", 16, "normal"))
    
def game_over():
    global running
    running = False
    game_over_display = turtle.Turtle()
    game_over_display.hideturtle()
    game_over_display.color("red")
    game_over_display.write("GAME OVER", align="center", font=("Arial", 36, "bold"))
    screen.update()
    time.sleep(2)
    screen.clear()
    screen.bye()

def game():
  global last_spawn_time,score
  screen.listen()
  screen.onkey(move_left, "Left")
  screen.onkey(move_right, "Right")
  current_time = time.time()
  if current_time - last_spawn_time > 2:
        spawn_balloon()
        last_spawn_time = current_time
  
        
  for b in balloonlist:
    b.sety(b.ycor() - b.speed)
    if b.ycor() < -200:
            balloonlist.remove(b)
            b.hideturtle()

        # Check for collision with dart
    if dart.distance(b) < 30:
        if b.is_bomb:
            game_over()
            return  # Exit immediately to avoid continuing after game over
        else:
            update_score(10)
            print(score)
        balloonlist.remove(b)
        b.hideturtle()
  screen.update()
  if running: 
    screen.ontimer(game, 20)


game()


