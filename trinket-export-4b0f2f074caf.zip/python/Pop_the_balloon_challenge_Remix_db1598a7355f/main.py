import turtle
import random
import time

# Screen setup
screen = turtle.Screen()
screen.bgcolor("skyblue")
screen.setup(width=800, height=600)
screen.tracer(0)

# Player setup
dart = turtle.Turtle()
dart.shape("triangle")
dart.color("red")
dart.penup()
dart.goto(0, -250)
dart.setheading(90)

# Score display
score = 0
score_display = turtle.Turtle()
score_display.hideturtle()
score_display.penup()
score_display.goto(-380, 260)
score_display.color("black")
score_display.write("Score: {}".format(score), font=("Arial", 16, "normal"))

# Balloon list
balloons = []

# Game variables
game_speed = 0.02
difficulty_increase = 0.001
spawn_interval = 2
last_spawn_time = time.time()
running = True


# Functions
def move_left():
    x = dart.xcor() - 30
    if x > -390:
        dart.setx(x)


def move_right():
    x = dart.xcor() + 30
    if x < 390:
        dart.setx(x)


def spawn_balloon():
    balloon = turtle.Turtle()
    balloon.penup()
    balloon.shape("circle")
    balloon.color(random.choice(["red", "green", "blue", "yellow"]))
    balloon.goto(random.randint(-350, 350), random.randint(200, 300))
    balloon.speed = random.uniform(1, 3)
    if random.random() < 0.2:  # 20% chance to be a bomb
        balloon.color("black")
        balloon.is_bomb = True
    else:
        balloon.is_bomb = False
    balloons.append(balloon)


def update_score(points):
    global score
    score += points
    score_display.clear()
    score_display.write("Score: {}".format(score), font=("Arial", 16, "normal"))


def game_over():
    global running
    running = False
    game_over_display = turtle.Turtle()
    game_over_display.hideturtle()
    game_over_display.color("red")
    game_over_display.write("GAME OVER", align="center", font=("Arial", 36, "bold"))
    screen.update()
    time.sleep(2)
    screen.bye()


# Key bindings
screen.listen()
screen.onkey(move_left, "Left")
screen.onkey(move_right, "Right")

# Game loop
while running:
    screen.update()
    current_time = time.time()

    # Spawn balloons at intervals
    if current_time - last_spawn_time > spawn_interval:
        spawn_balloon()
        last_spawn_time = current_time

    # Move balloons
    for balloon in balloons[:]:
        balloon.sety(balloon.ycor() - balloon.speed)
        if balloon.ycor() < -300:
            balloons.remove(balloon)
            balloon.hideturtle()

        # Check for collision with dart
        if dart.distance(balloon) < 30:
            if balloon.is_bomb:
                game_over()
            else:
                update_score(10)
            balloons.remove(balloon)
            balloon.hideturtle()

    # Increase difficulty over time
    game_speed = max(0.005, game_speed - difficulty_increase)  # Prevent negative game_speed
    spawn_interval = max(0.5, spawn_interval - 0.0005)         # Prevent too-frequent spawns

    time.sleep(game_speed)