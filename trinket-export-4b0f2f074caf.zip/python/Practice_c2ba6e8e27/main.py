import turtle

pen = turtle.Turtle();
paper = turtle.Screen();

paper.bgcolor("pink");

pen.goto(0,0)


for i in range(36):
  pen.forward(10);
  pen.right(10);
  
for i in range(36):
  pen.forward(6);
  pen.left(10);