f = input("Enter the file name to be opened")
try:
  with open(f, "r") as file:
      print(file.read())
except FileNotFoundError:
  print("File named {} is not found...".format(f))