import turtle
import random

y_pos = -100

# Create screen
screen = turtle.Screen()
screen.bgcolor("white")

#create user turtle
user = turtle.Turtle()
user.shape("turtle")
user.color("red")
user.penup()
user.goto(-200, 100)


# Function to move the user turtle
def move_right():
  x = user.xcor()
  r = random.randint(20,60)
  user.setx(x + r)


"""
another way of moving the turtle:
def move_right():
    user.forward(10)
 """

# Keyboard events
screen.listen()
screen.onkey(move_right, "Right")

# Create players
colors = ["blue", "green", "orange", "purple"]
players = []

# Position and create players
for color in colors:
  player = turtle.Turtle()
  player.shape("turtle")
  player.color(color)
  player.penup()
  player.goto(-200, y_pos)
  players.append(player)
  y_pos += 50


# Move players forward
def move_players():
  for player in players:
    distance = random.randint(1, 10)
    player.forward(distance)


# Game loop
game_over = False
while not game_over:
  move_players()
  for player in players:
    if player.xcor() >= 200:
      game_over = True
      
      if user.xcor() > player.xcor():
        #winner = "red"
        print("You Win")
        exit()
      else:
        #winner = player.color()[0]
        print("You Lose")
      break

# Display the winner
"""
if winner:
  turtle.write(f"The {winner.upper()} turtle wins!",
               align="center",
               font=("Arial", 16, "bold"))
"""
turtle.hideturtle()
