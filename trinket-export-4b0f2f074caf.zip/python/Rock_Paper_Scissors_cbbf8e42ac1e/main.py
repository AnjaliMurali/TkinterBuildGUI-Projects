import random, os, time

uscore = 0
compscore = 0
i = 0
while (i < 10):
  i += 1
  #time.sleep(2)
  #os.system('clear')
  print("\n")
  print("Round:" + str(i))
  print("1.ROCK\n2.PAPRER\n3.SCISSORS")

  choice = int(input("Enter you choice - 1/2/3?"))
  if (choice == 1):
    print("You : Rock")
  elif choice == 2:
    print("You : PAPER")
  else:
    print("You : SCISSORS")

  comp = random.randint(1, 3)
  if (comp == 1):
    print("Computer  : Rock")
  elif comp == 2:
    print("Computer  : PAPER")
  else:
    print("Computer  : SCISSORS")

  print("Result:")
  if choice == comp:
    print("That was a draw. No score added")
  elif choice == 1:
    if comp == 2:
      print("Computer Won!")
      compscore += 1
    elif comp == 3:
      print("You won")
      uscore += 1
  elif choice == 2:
    if comp == 3:
      print("Computer Won!")
      compscore += 1
    elif comp == 1:
      print("You won")
      uscore += 1
  elif choice == 3:
    if comp == 1:
      print("Computer Won!")
      compscore += 1
    elif comp == 2:
      print("You won")
      uscore += 1

time.sleep(2)
os.system('clear')

print("After 10 rounds, the score board shows: ")
print("Computer : {} and YOU : {}".format(compscore, uscore))
if (uscore > compscore):
  print("Congratulations! You won the game")
else:
  print("Computer won! Better luck next time! ")
