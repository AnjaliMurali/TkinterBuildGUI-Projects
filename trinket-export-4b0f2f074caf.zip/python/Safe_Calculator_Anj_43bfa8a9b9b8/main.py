while True: 
  try:
    num1 = float(input("Enter the first number: "))
  except ValueError:
    print("Invalid input! Please enter a valid number.")
    continue
  try:
    num2 = float(input("Enter the second number: "))
  except ValueError:
    print("Invalid input! Please enter a valid number.")
    continue
  op = input("Enter operator (+, -, *, /): ").strip()
  try:
    if(op=="+"):
      result = num1 + num2
    elif(op=="-"):
      result = num1 - num2
    elif(op=="*"):
      result = num1 * num2
    elif(op=="/"):
      result = num1 / num2
    else:
      raise ValueError
  except ZeroDivisionError:
      print("Error: Cannot divide by zero!")
      continue
  except ValueError:
      print("Invalid operator! Please use +, -, *, or /.")
      continue
  print(result)
  continue_calc = input("Do you want to perform another calculation? (yes/no): ").strip().lower()
  if continue_calc != 'yes':
      print("Thank you for using the Safe Calculator. Goodbye!")
      break