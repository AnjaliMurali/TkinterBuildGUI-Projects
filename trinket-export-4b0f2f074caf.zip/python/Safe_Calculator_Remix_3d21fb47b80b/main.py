"""
Common Built-in Exceptions : 
ZeroDivisionError: Division by zero.
ValueError: Invalid value (e.g., converting a letter to an int).
TypeError: Operation on an incompatible type (e.g., adding string to int).
IndexError: Index out of range in sequences like lists.
KeyError: Key not found in a dictionary.
ImportError: Failed import.
FileNotFoundError: File does not exist.
NameError: Variable/function name not defined.
"""


def safe_calculator():
    print("Welcome to the Safe Calculator!")

    while True:
        # Taking input from the user for the first number
        try:
            num1 = float(input("Enter the first number: "))
        except ValueError:
            print("Invalid input! Please enter a valid number.")
            continue

        # Taking input from the user for the second number
        try:
            num2 = float(input("Enter the second number: "))
        except ValueError:
            print("Invalid input! Please enter a valid number.")
            continue

        # Taking input from the user for the operator
        operator = input("Enter operator (+, -, *, /): ").strip()

        # Performing the calculation
        try:
            if operator == "+":
                result = num1 + num2
            elif operator == "-":
                result = num1 - num2
            elif operator == "*":
                result = num1 * num2
            elif operator == "/":
                result = num1 / num2  # ZeroDivisionError will be caught if num2 == 0
            else:
                raise ValueError("Invalid operator")
        except ZeroDivisionError:
            print("Error: Cannot divide by zero!")
            continue
        except ValueError:
            print("Invalid operator! Please use +, -, *, or /.")
            continue

        print("The result is: {}".format(result))

        # Asking if the user wants to perform another calculation
        continue_calc = input("Do you want to perform another calculation? (yes/no): ").strip().lower()
        if continue_calc != 'yes':
            print("Thank you for using the Safe Calculator. Goodbye!")
            break

# Running the calculator
safe_calculator()
