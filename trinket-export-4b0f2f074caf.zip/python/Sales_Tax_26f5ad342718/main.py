choice = "y"
print("Hello there!")
while choice!= "n":
  item1=input("Enter product name")
  price1=int(input("Enter price of product"))
  number1=int(input("Enter number of products bought"))
  price1 *=number1
  exempt1=input("Is it exempted [y/n]")
  if exempt1 == "n":
    price1=price1+(price1/10)
  import1=input("Is it imported [y/n]")
  if import1 == "y":
    price1=price1+(price1/20)
  print("Total amount = " + str(price1))
  choice = input("Do you want to check the tax for more product [y/n] ")