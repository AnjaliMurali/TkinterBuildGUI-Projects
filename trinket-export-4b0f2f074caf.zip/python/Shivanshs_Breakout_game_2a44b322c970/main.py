import turtle
import time
import random

screen = turtle.Screen()
screen.setup(800,600)
screen.bgcolor("black")
brick_coordinates = ((-30,15),(30,15),(30,-15),(-30,-15))
screen.register_shape("rectangle", brick_coordinates)
bricks_list = []
colors_list = ["red","orange","yellow","light blue","lightgreen"]

for c in range(5):
  for i in range(-330,350,95):
    bricks = turtle.Turtle()
    bricks.speed(0)
    bricks.goto(i,250-(c*65))
    bricks.color(colors_list[c])
    bricks.shape("rectangle")
    bricks.setheading(90)
    bricks_list.append(bricks)
    
paddle = turtle.Turtle()
paddle.penup()
paddle.setheading(90)
paddle.goto(0,-150)
paddle_coordinates = ((-90,10),(90,10),(90,-10),(-90,-10))
screen.register_shape("paddlelength", paddle_coordinates)
paddle.shape("paddlelength")
paddle.color("white")
   

ball = turtle.Turtle()
ball.penup()
ball.shape("circle")
ball.color("white")
ball.goto(0,-100)
random_x = random.randint(-3,3)
random_y = random.randint(-3,3)
ball.dx = random_x
ball.dy = random_y
game_started = False
start = 0
first_click = False

def start_game(x, y):
    global game_started, start, first_click

    game_started = True

    # Start timer only once
    if first_click == False:
        start = time.time()
        first_click = True
        
screen.onclick(start_game)

def paddle_left():
  x = paddle.xcor()
  if x > -290:
    paddle.setx(x-10)

def paddle_right():
  x = paddle.xcor()
  if x < 290:
    paddle.setx(x+10)

screen.listen()
screen.onkey(paddle_left,"Left")
screen.onkey(paddle_right,"Right")
score = 0
score_display = turtle.Turtle()
score_display.color("white")
score_display.hideturtle()
score_display.penup()
score_display.goto(-350,-200)
score_display.pendown()
score_display.write("Score: " + str(score), font = ("Arial", 20, "bold" ))
def score_update():
  global score
  score_display.clear()
  score_display.write("Score: " + str(score), font = ("Arial", 20, "bold" ))


timer = 10
timer_display = turtle.Turtle()
timer_display.color("white")
timer_display.hideturtle()
timer_display.penup()
timer_display.goto(-350,-250)
timer_display.pendown()
timer_display.write("Time: " + str(timer), font = ("Arial", 20, "bold" ))
timer_display.color("white")

def timer_update():
  global timer
  timer_display.clear()
  timer_display.write("Time: " + str(timer), font = ("Arial", 20, "bold" ))

def Game_over():
   game_over = turtle.Turtle()
   game_over.color("white")
   screen.bgcolor("black")
   game_over.goto(-200,0)
   game_over.write("GAME OVER!!!, You Win " + str(timer), font = ("Arial", 40, "bold" ))
   
def Lose():
   lose = turtle.Turtle()
   screen.bgcolor("black")
   lose.color("white")
   lose.goto(-200,0)
   lose.penup()
   lose.write("Time's Up!!!, You Lose " + str(timer), font = ("Arial", 40, "bold" ))
   
   
   
while True:
 
  screen.update()
  time.sleep(0.01)
  
  elapsed_time = int(time.time() - start)
  remaining_time = 10 - elapsed_time
  #time = remaining_time + elapsed_time
  if remaining_time != timer and remaining_time >= 0:
    timer = remaining_time
    timer_update()
 
  if game_started == True:
    
    ball.setx(ball.xcor()+ball.dx)
    ball.sety(ball.ycor()+ball.dy)
    if ball.xcor() < -400:
      ball.dx *= -1
    if ball.xcor() > 400:
      ball.dx *= -1
    if ball.ycor() > 300:
      ball.dy *= -1
    if ball.ycor() < -150:
      ball.goto(0,-100)
      ball.dy *= -1
      game_started = False
    if -135 < ball.ycor() < -130  and (paddle.xcor() - 30 < ball.xcor() < paddle.xcor() + 30):
      ball.dy *= -1
  for bricks in bricks_list[:]:
    if abs(ball.xcor() - bricks.xcor()) < 20 and abs(ball.ycor() - bricks.ycor()) < 20:
      ball.dy *= -1
      bricks.hideturtle()
      bricks_list.remove(bricks)
      score = score + 10
      score_display.clear()
      score_display.write("Score: " + str(score), font = ("Arial", 20, "bold" ))
  if score>190 and timer!=0:
    game_started = False
    Game_over()
  if timer == 0:
    game_started = False
    Lose()
  
    
    
    
  
  

  
  








































