import turtle
import random
import time

dart = turtle.Turtle()
paper = turtle.Screen()
paper.setup(600,650)
paper.bgcolor("light blue")
paper.tracer(0)
dart.shape("triangle")
dart.penup()
dart.goto(0,-300)
dart.right(30)
dart.color("red")

def move_left():
  x = dart.xcor() - 15
  dart.setx(x)
def move_right():
  x = dart.xcor() + 15
  dart.setx(x)
  

paper.listen()
paper.onkey(move_left, "Left")
paper.onkey(move_right, "Right")

balloons = []

def spawn_balloon():
  balloon = turtle.Turtle()
  balloon.shape("circle")
  color_list = ["red","green","blue","yellow","purple","black"]
  c = random.choice(color_list)
  balloon.color(c)
  balloon.my_color = c
  balloon.penup()
  balloon.goto(random.randint(-250,250),300)
  if c == "red":
    balloon.speed = 6
  elif c == "purple":
    balloon.speed = 5
  elif c == "blue":
    balloon.speed = 4
  elif c == "green":
    balloon.speed = 3
  elif c == "yellow":
    balloon.speed = 2
  elif c == "black":
    balloon.speed = random.randint(2,6)
  
  balloons.append(balloon)
  
spawn_interval = 1
last_spawn_time = time.time()

score = 0
score_display = turtle.Turtle()
score_display.hideturtle()
score_display.color("white")
score_display.penup()
score_display.goto(-290,300)
score_display.pendown()
score_display.write("Score: " + str(score), font = ("Arial", 20, "bold" ))
def score_update():
  global score
  score_display.clear()
  score_display.write("Score: " + str(score), font = ("Arial", 20, "bold" ))
  

start = time.time()
timer = 10
timer_display = turtle.Turtle()
timer_display.hideturtle()
timer_display.penup()
timer_display.goto(-290,250)
timer_display.pendown()
timer_display.write("Time: " + str(timer), font = ("Arial", 20, "bold" ))

def timer_update():
  global timer
  timer_display.clear()
  timer_display.write("Time: " + str(timer), font = ("Arial", 20, "bold" ))

def Game_over():
  global running
  pen = turtle.Turtle()
  running = False
  paper.bgcolor("black")
  pen.color("white")
  pen.write("GAME OVER !!! ", font = ("Arial", 50, "bold" ), align = "center")
  pen.hideturtle()
  paper.update()
running = True 
while running:
  paper.update()
  elapsed_time = int(time.time() - start)
  remaining_time = 10 - elapsed_time
  if remaining_time != timer and remaining_time >= 0:
    timer = remaining_time
    timer_update()
  if remaining_time <= 10:
    timer_display.color("red")
  current_time = time.time()
  if current_time - last_spawn_time >= spawn_interval:
    spawn_balloon()
    last_spawn_time = current_time
  if score < 50 and remaining_time == 0:
    Game_over()
  for balloon in balloons[:]:
    balloon.sety(balloon.ycor() - balloon.speed)
    if balloon.ycor() < -325:
      balloons.remove(balloon)
      balloon.hideturtle()
    if dart.distance(balloon) < 10:      
      if balloon.my_color == "red":
        score = score + 5
        score_update()
      elif balloon.my_color == "purple":
        score = score + 4
        score_update()
      elif balloon.my_color == "blue":
        score = score + 3
        score_update()
      elif balloon.my_color == "green":
        score = score + 2
        score_update()
      elif balloon.my_color == "yellow":
        score = score + 1
        score_update()
      elif balloon.my_color == "black":
        score = score - 3
        score_update()
      balloons.remove(balloon)
      balloon.hideturtle()
  spawn_interval = max(spawn_interval - 0.001,0.5)
      
      
      
  time.sleep(0.04)
  

  
  
  
  
  

























