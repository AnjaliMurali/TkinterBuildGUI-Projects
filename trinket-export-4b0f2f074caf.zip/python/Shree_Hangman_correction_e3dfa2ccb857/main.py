import random

# WordGuess
wg = 5

print("Welcome to hangman; it's a rip-off...")

hangman = ["squirrel","guitar","necklace", "gluestick", "globe", "circuit", "yearbook", "pencil", "uniform", "holepunch" , "keychain","bandana","ultimate", "dutch", "english", "spanish", "german", "drama", "french", "tshirt" , "hairdryer","nightlamp","bubblegum", "geography", "geology", "computer science", "sculpture", "portrait", "photographs", "academic commitment award"] 

word = random.choice(hangman)
print(word)
# GuessWord
gw = ["_"]*len(word)
#print(" ".join(gw))

while "_" in gw and wg!= 0:
  print("Progress: " + " ".join(gw))
  guess = input("Guess a letter")
  
  if guess in word:
    print("That's correct!")
    for i in range(len(word)):
      if word[i] == guess:
        gw[i] = guess
  else: 
    wg = wg - 1
    print("Wrong. You have " + str(wg) + " attempts left")
    if wg == 0:
      print("The word was " + word + ".")
# Just move the print progress to the top in while loop and comment the other print in line 14. 