import turtle

pen=turtle.Turtle()
paper=turtle.Screen()

def drawrectangle(x,y,height,width):
  pen.pensize(3)
  pen.penup()
  c= input("What color do you want the rectangle to be?")
  pen.goto(x,y)
  pen.pendown()
  pen.color(c)
  pen.fillcolor(c)
  pen.begin_fill()
  
  for i in range (2):
    pen.forward(height)  
    pen.right(90)
    pen.forward(width)  
    pen.right(90)
  pen.end_fill() 


drawrectangle(20, 30, 150, 100)
drawrectangle(15, 55, 160, 25)
drawrectangle(30,10, 20, 20)
drawrectangle(140,10, 20, 20)
drawrectangle(90,-30, 30, 40)