import turtle
import random

snake=turtle.Turtle()
screen=turtle.Screen()
food=turtle.Turtle()
food.shape("circle")
food.color("red")
screen.bgcolor("green")
snake.pencolor("blue")
snake.direction="stop"
snake.speed(1)
Snakes=[]

x = random.randint(-150,150)
y = random.randint(-150,150)
food.penup()
food.goto(x,y)

def W():
  snake.direction="up"
  snake.setheading(90)

def A():
  snake.direction="left"
  snake.setheading(180)

def S():
  snake.direction="down"
  snake.setheading(270)

def D():
  snake.direction="right"
  snake.setheading(0)

def move():
  if snake.direction=="up":
    y = snake.ycor()
    snake.sety(y+20)
    
  if snake.direction=="left":
    x = snake.xcor()
    snake.setx(x-20)

  if snake.direction=="down":
    y = snake.ycor()
    snake.sety(y-20)
       
  if snake.direction=="right":
    x = snake.xcor()
    snake.setx(x+20)

screen.listen()
screen.onkey(W,"w")
screen.onkey(A,"a")
screen.onkey(S,"s")
screen.onkey(D,"d")


while True:
  move()
  if snake.distance(food)<15:
    x = random.randint(-150,150)
    y = random.randint(-150,150)
    food.goto(x,y)
    
    newSnake=turtle.Turtle()
    newSnake.shape("square")
    Snakes.append(newSnake)
    
  for i in range(len(Snakes)-1,0,-1):
        x=Snakes[i-1].xcor()
        y=Snakes[i-1].ycor()
        Snakes[i].goto(x,y)
        
  if len(Snakes):
    x = snake.xcor()
    y = snake.ycor()
    Snakes[0].goto(x,y)