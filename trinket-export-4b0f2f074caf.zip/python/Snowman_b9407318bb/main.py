import turtle

pen = turtle.Turtle()
paper = turtle.Screen()

paper.setup(500,800)

pen.pendown()

pen.speed(50)


paper.bgcolor("#ADD8E6")
pen.pencolor("red")
pen.fillcolor("white")

pen.begin_fill()
for i in range(36):
  pen.forward(10)
  pen.right(10)
pen.end_fill()

pen.begin_fill()
for i in range(36):
  pen.forward(5)
  pen.left(10)
pen.end_fill()

pen.penup()
pen.goto(0,-100)
pen.pendown()
pen.begin_fill()
for i in range(36):
  pen.forward(15)
  pen.right(10)
pen.end_fill()

pen.penup()
pen.goto(-10,35)
pen.pendown()
pen.pencolor("black")
pen.fillcolor("black")
pen.begin_fill()
pen.circle(2)
pen.end_fill()

pen.penup()
pen.goto(10,35)
pen.pencolor("black")
pen.fillcolor("black")
pen.begin_fill()
pen.pendown()
pen.circle(2)
pen.end_fill()

pen.penup()
pen.goto(15,30)
pen.pendown()
pen.right(90)
for i in range(18):
  pen.forward(2.5)
  pen.right(10)

pen.speed(10)
pen.penup()
pen.pencolor("red")
pen.goto(40,-20)
pen.pendown()
pen.right(45)
pen.forward(40)

pen.left(30)
pen.forward(10)
pen.forward(-10)
pen.right(60)
pen.forward(10)
pen.forward(-10)

turtle.setheading(0) 

pen.penup()
pen.pencolor("red")
pen.goto(-40,-20)
pen.pendown()
pen.left(135)
pen.forward(40)

pen.left(30)
pen.forward(10)
pen.forward(-10)
pen.right(60)
pen.forward(10)
pen.forward(-10)


pen.hideturtle()