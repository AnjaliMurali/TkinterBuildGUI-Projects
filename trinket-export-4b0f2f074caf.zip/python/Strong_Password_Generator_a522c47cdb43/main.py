import random,time,os,sys

while True: 
  lo=["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]
  up=["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
  sp=["!","@","#","$","%","^","&","*","(",")","_","-","+","=","{","}","[","]","|","<",">"]
  num = ["1","2","3","4","5","6","7","8","9","10"]
  lo1 = random.choice(lo)
  up1 = random.choice(up)
  sp1= random.choice(sp)
  num1 = random.randint(0,9)
  lo2 = random.choice(lo)
  up2 = random.choice(up)
  sp2= random.choice(sp)
  num2 = random.randint(0,9)
  #pw = str(lo1)+str(sp1)+str(up1)+str(num1)+str(lo2)+str(sp2)+str(up2)+str(num2)
  #print(pw)
  pw = str("Strong password is {}{}{}{}{}{}{}{}".format(lo1,sp1,up1,num1,lo2,sp2,up2,num2))
  print(pw)
  x = input("satisfied - y/n?")
  if(x == "y"):
    exit()
  time.sleep(1)