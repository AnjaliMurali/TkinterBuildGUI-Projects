tasks = []

while True:
        print("\n--- To-Do List Menu ---")
        print("1. View tasks")
        print("2. Add a task")
        print("3. Remove a task")
        print("4. Exit")
        print("5. Edit a task")
        
        choice = input("Choose an option (1-4): ")
        if choice == "1":
            for i in tasks:
              print(i)
            
        elif choice == "2":
            task = input("Enter the task to add: ")
            tasks.append(task)
            print("Task '" + task + "' added!")
            
        elif choice == "3":
            task = input("Enter the name of the task you want to remove: ")
            tasks.remove(task)
            print("Task '" + task + "' removed!")
            
        elif choice == "4":
            print("Exiting To-Do List App. Goodbye!")
            break
          
        elif choice=="5":
            task1 = input("enter the task you want to edit")
            task2 = input("Enter the editted task")
            count=0;
            for i in tasks:
              if i == task1:
                tasks[count]=task2
                print(task1 + " is updated to " + task2)
              else:
                count+=1;
            
              
        else:
            print("Invalid choice. Please select a valid option.")