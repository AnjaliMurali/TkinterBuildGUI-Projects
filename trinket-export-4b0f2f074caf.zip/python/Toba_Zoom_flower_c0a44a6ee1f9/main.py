import turtle
pen = turtle.Turtle()
paper = turtle.Screen()

import random

paper.bgcolor("blue")
pen.speed(100)
for x in range(20):
  pen.penup()
  red = random.randint(0,255)
  yellow = random.randint(0,255)
  green = random.randint(0,255)
  num = random.randint(6,10)
  pos1 = random.randint(-150,150)
  pos2 = random.randint(-150,150)
  size = random.randint(20,100)
  pen.goto(pos1,pos2)
  for x in range(num):
    pen.fillcolor(red,yellow,green)
    pen.pendown()
    pen.begin_fill()
    #draw 1 petal
    pen.circle(size,60)
    pen.left(120)
    pen.circle(size,60)
    #to draw num petals to make the flower
    pen.left(360/num)
    pen.end_fill()