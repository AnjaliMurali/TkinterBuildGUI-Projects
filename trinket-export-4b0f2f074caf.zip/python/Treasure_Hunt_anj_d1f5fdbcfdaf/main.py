import random
grid = []

def initialize_grid():
  for i in range(5):
    row = []  # Temporary list to store elements of each row
    # Loop to create 5 columns
    for j in range(5):
        row.append('-')  # Append '-' to the row
    grid.append(row)  # Add the row to the grid
    # Create a 5x5 grid filled with '-'
  return grid
  
  
def give_hint(treasure_row, treasure_col, guess_row, guess_col):
    if guess_row < treasure_row:
        return "Move down"
    elif guess_row > treasure_row:
        return "Move up"
    elif guess_col < treasure_col:
        return "Move right"
    elif guess_col > treasure_col:
        return "Move left"
    return "Congratulations! You found the treasure!"
  
  
initialize_grid()
print("Welcome to the Treasure Hunt Game!")
attempts = 0  # Initialize the attempt counter
print("\nCurrent Grid:")
for row in grid:
    print(" ".join(row)) #the join() method is being used to combine elements of the list row into a single string, with a space (" ") between each element.

#Treasure is here:   
treasure_row = random.randint(0, 4)  # Random row between 0 and 4
treasure_col = random.randint(0, 4) 

while True: 
  #print("\n" * 100) # if you want to clear the screen.This will only push the console up as trinket doesn't allow the usual method of clearing the console. Its just a work around. 
  try:
      guess_row = int(input("Enter the row number (0-4): "))
      guess_col = int(input("Enter the column number (0-4): "))
  except ValueError:
      print("Invalid input. Please enter numbers between 0 and 4.")
      continue
  if guess_row not in range(5) or guess_col not in range(5):
      print("Invalid input. Please choose a row and column between 0 and 4.")
      continue
  attempts += 1
  if guess_row == treasure_row and guess_col == treasure_col:
      print("Congratulations! You found the treasure in {} attempts.".format(attempts))
      break
  else:
      # Provide a hint
      hint = give_hint(treasure_row, treasure_col, guess_row, guess_col)
      print("Hint: {}".format(hint))
      print("*"*40)