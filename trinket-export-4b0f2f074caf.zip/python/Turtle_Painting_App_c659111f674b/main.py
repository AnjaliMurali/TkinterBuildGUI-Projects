import turtle

# Setup screen
screen = turtle.Screen()
#screen.title("Turtle Painting App")
screen.bgcolor("white")

# Create turtle
pen = turtle.Turtle()
pen.shape("turtle")
pen.speed(0)
pen.pensize(3)

# Move functions
MOVE_DISTANCE = 20

def move_up():
    pen.setheading(90)
    pen.forward(MOVE_DISTANCE)

def move_down():
    pen.setheading(270)
    pen.forward(MOVE_DISTANCE)

def move_left():
    pen.setheading(180)
    pen.forward(MOVE_DISTANCE)

def move_right():
    pen.setheading(0)
    pen.forward(MOVE_DISTANCE)

# Color change functions
colors = ["red", "blue", "green", "yellow", "purple", "orange"]

def set_red():
    pen.color("red")

def set_blue():
    pen.color("blue")

def set_green():
    pen.color("green")

def set_yellow():
    pen.color("yellow")

def set_purple():
    pen.color("purple")

def set_orange():
    pen.color("orange")

# Clear screen
def clear_drawing():
    pen.clear()
    pen.penup()
    pen.home()
    pen.pendown()

# Keyboard bindings
screen.listen()

# Arrow keys for movement
screen.onkey(move_up, "Up")
screen.onkey(move_down, "Down")
screen.onkey(move_left, "Left")
screen.onkey(move_right, "Right")

# Color keys
screen.onkey(set_red, "r")
screen.onkey(set_blue, "b")
screen.onkey(set_green, "g")
screen.onkey(set_yellow, "y")
screen.onkey(set_purple, "p")
screen.onkey(set_orange, "o")

# Clear drawing
screen.onkey(clear_drawing, "c")

# Keep window open
screen.mainloop()