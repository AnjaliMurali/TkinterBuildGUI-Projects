import random
full_name = input("Enter your full name (or type 'exit' to quit): ")

name_parts = full_name.split()
if len(name_parts) < 2:
    print("Please enter a full name (first and last).")
else:

  first_name = name_parts[0].lower()
  last_name = name_parts[-1].lower()
  
  # Basic combinations
  username1 = first_name + last_name
  username2 = first_name[:3] + last_name[-3:]
  username3 = last_name[:3] + first_name[-2:]
  
  # Add random numbers
  rand_num = random.randint(10, 99)  # generate a random number between 10 and 99
  username4 = first_name + str(rand_num)
  username5 = last_name + str(rand_num)
  
  # More creative combinations
  username6 = first_name[1:3] + last_name[-4:-1] + str(random.randint(1,9))
  
  #HomeWork
  username7 = first_name +"." + last_name
  username8 = first_name +"_" + last_name
  sp = ["@","!","#"]
  username9 = first_name + last_name + random.choice(sp)
  
  usernames = [username1, username2, username3, username4, username5, username6,username7,username8,username9]
  print(random.choice(usernames))
