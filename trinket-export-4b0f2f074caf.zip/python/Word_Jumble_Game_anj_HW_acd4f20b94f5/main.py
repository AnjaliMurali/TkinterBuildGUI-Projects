import random

# List of words to choose from
word_list_medium = ['python', 'javascript', 'java', 'html', 'css', 'developer', 'algorithm', 'computer', 'data', 'machine']
word_list_easy = ["captain","snowball","minecraft","delete","insert","button","bubble","screen","carboard","result"]
word_list_difficult = ["string","sequence","fortnite","backspace","ferrari","calculator","microbit","instructions","impossible","jetlearn","redeem","favourites"]

def jumble_word(word):
    words_list = list(word) # Convert the word to a list of characters
    random.shuffle(words_list)  # Shuffle the characters
    return ''.join(words_list)  # Convert the shuffled list back into a string
    

def get_hint(word):
    # Provide the first letter of the word as a hint
    return "The first letter of the word is: {}".format(word[0].upper())

def play_game():
    score = 0
    rounds = 5  # Number of rounds to play
    
    print("Welcome to the Advanced Word Jumble Game!")
    
    while True: 
      mode = input("enter difficulty level - easy(e)/medium(m)/hard(h)")
      if mode == "e":
        word_list = word_list_easy
        break
      elif mode == "m":
        word_list = word_list_medium
        break
      elif mode == "h":
        word_list = word_list_difficult
        break
      else:
        print("Enter a valid response - e/m/h. Try again.")
    
    
    for round_number in range(1, rounds + 1):
        # Choose a random word from the list
        words = random.choice(word_list)
        scrambled_word = jumble_word(words)
        
        print("\nRound {}:".format(round_number))
        print("Here is the scrambled word: {}".format(scrambled_word))
        
        # Option for a hint
        hint_choice = input("Do you want a hint? (yes/no): ").lower()
        if hint_choice == 'yes':
            print(get_hint(words))
        
        # Allow the user to guess the original word
        guess = input("Guess the original word: ").lower()
        
        # Input validation
        while not guess.isalpha():
            print("Please enter a valid word!")
            guess = input("Guess the original word: ").lower()
        
        # Check if the guess is correct
        if guess == words:
            print("Congratulations! You guessed it right!")
            score += 1  # Increase the score for a correct guess
        else:
            print("Oops! The correct word was: {}".format(words))
    
    # Final score
    print("\nGame Over! Your final score is {}/{}.".format(score,rounds))

# Run the game
play_game()