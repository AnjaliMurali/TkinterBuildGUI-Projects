import turtle
import random

t = turtle.Turtle()
t.speed(50)

sc = turtle.Screen()
sc.bgcolor('gold')

"""for i in range(6):
  t.circle(100,60)
  t.left(120)
  t.circle(100,60)
  t.left(360/6)"""

def petal(r):
  t.circle(r,60)
  t.left(120)
  t.circle(r,60)
  
#petal(50)

def flower(n):
  for i in range(n):
    petal(25)
    f= 360/n
    print(f)
    t.left(f)

flower(10)
    