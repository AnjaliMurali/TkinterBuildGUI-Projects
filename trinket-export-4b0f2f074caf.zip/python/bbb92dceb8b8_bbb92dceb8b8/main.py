import turtle
import time

# Set up the screen
screen = turtle.Screen()
screen.setup(width=600, height=400)
screen.tracer(0) 
screen.bgcolor("black")

rectCors = ((-60,10),(60,10),(60,-10),(-60,-10));
screen.register_shape('rectangle',rectCors);

rectCors1 = ((-20,10),(20,10),(20,-10),(-20,-10));
screen.register_shape('rectBrick',rectCors1);


# Paddle
paddle = turtle.Turtle()
#paddle.shape("square")
paddle.shape('rectangle');
paddle.setheading(90)
paddle.color("gray")
paddle.penup()
paddle.speed(0)
paddle.goto(0, -180)
paddle_width = 120  # Paddle width in pixels

# Paddle movement
def paddle_left():
    x = paddle.xcor()
    if x - paddle_width // 2 > -300:  # Prevent going off-screen
        paddle.setx(x - 20)

def paddle_right():
    x = paddle.xcor()
    if x + paddle_width // 2 < 300:  # Prevent going off-screen
        paddle.setx(x + 20)

screen.listen()
screen.onkey(paddle_left, "Left")
screen.onkey(paddle_right, "Right")


# Bricks
brick = turtle.Turtle()
brick.shape("rectBrick")
brick.color("red")  # Different colors for each row
brick.penup()
brick.speed(0)
brick.setheading(90)
brick.goto(-250,150)
#brick.goto(x, 150 - (row * 30))
#bricks.append(brick)