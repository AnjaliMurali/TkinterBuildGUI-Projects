import turtle

# Screen setup
screen = turtle.Screen()
screen.title("Indian Flag")
t = turtle.Turtle()
t.speed(8)

# Function to draw a filled rectangle
def draw_rectangle(color, x, y, width, height):
    t.up()
    t.goto(x, y)
    t.down()
    t.fillcolor(color)
    t.begin_fill()
    for _ in range(2):
        t.forward(width)
        t.right(90)
        t.forward(height)
        t.right(90)
    t.end_fill()

# Draw saffron rectangle
draw_rectangle("#FF9933", -200, 100, 400, 60)

# Draw white rectangle
draw_rectangle("white", -200, 40, 400, 60)

# Draw green rectangle
draw_rectangle("#138808", -200, -20, 400, 60)

# Draw Ashoka Chakra
t.up()
t.goto(0, 40)
t.down()
t.color("#000080")
t.width(2)
t.circle(30)

# Draw 24 spokes
t.up()
t.goto(0, 40)
t.setheading(90)
t.down()

for i in range(24):
    t.forward(30)
    t.backward(30)
    t.right(15)

t.hideturtle()
turtle.done()
