import random
import turtle

screen = turtle.Screen()

screen.bgcolor("black")
t = turtle.Turtle() 
t.pensize(3)
t.speed(100)
for i in range(15):

  x = random.randint(-500,500)
  y = random.randint(-500,500)

  t.penup()
  t.goto(x,y)
  t.pendown()
  i = 36 
  r = random.randint(0,255)
  g = random.randint(0,255)
  b = random.randint(0,255)
  t.color(r,g,b)
  while i>0 :
    i = i - 1 
    a = random.randint(60,80)
    t.forward(a)
    t.backward(a)
    t.left(10)

screen.mainloop()


