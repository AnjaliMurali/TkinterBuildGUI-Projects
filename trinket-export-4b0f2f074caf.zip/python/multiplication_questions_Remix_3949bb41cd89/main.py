import turtle
pen=turtle.Turtle()
paper=turtle.Screen()
import random

while True:
  a=random.randint(1,10)
  b=random.randint(1,10)
  pen.clear()
  ans=int(input("what is "+str(a)+"*"+str(b)+"?"))
  c=a*b
  
  if ans==c:
    print("correct!")
    pen.write("Correct!")
    
  else:
    print("Incorrect")
    pen.write("incorrect!")
    
    
  ar=input("Do you want another question?")
  if ar=="no":
    break
