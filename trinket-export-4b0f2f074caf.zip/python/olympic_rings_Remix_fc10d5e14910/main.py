import turtle
pen=turtle.Turtle()
paper=turtle.Screen()

def ring(x,y,c):
  pen.penup()
  pen.goto(x,y)
  pen.pendown()
  pen.pencolor(c)
  pen.circle(30)

ring(70,15,"red")
ring(-40,-15,"yellow")
ring(30,-15,"green")
ring(-10,15,"black")
ring(-80,15,"blue")