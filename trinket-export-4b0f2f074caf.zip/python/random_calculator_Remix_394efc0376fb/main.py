import random

fn=int(input("What is the first number?"))
sn=int(input("What is the second number?"))
op=["+", "-", "*", "/", "%"]
o=random.choice(op)

if o=="+":
  a=fn+sn
  print("The sum of the numbers is "+str(a))
if o=="-":
  a=fn-sn
  print("The difference of the numbers is "+str(a))
if o=="*":
  a=fn*sn
  print("The product of the numbers is "+str(a))
if o=="/":
  a=fn/sn
  print("The division of the numbers is "+str(a))
if o=="%":
  a=fn%sn
  print("The remainder after dividing the numbers is "+str(a))

