def c_g(q1,q2):
  c_gD={"flour":120,"sugar":200,"butter":225}
  if q2 in c_gD:
    A_g=c_gD[q2]*q1
    return A_g
  else:
    return("Not An Option")
def ta_te(q3):
  a_te=q3*3
  return a_te
def g_c(q4,q5):
  g_cD={"flour":120,"sugar":200,"butter":225}
  if q2 in g_cD:
    A_c=q4/g_cD[q5]
    return A_c
  else:
    return("Not An Option")
print(".---=Convertions=---.\n1.Cups --> Grams\n2.Tablespoons --> Teaspoons\n3.Grams --> Cups\n4.Exit")
while True:
  a1=input("Choose An Option (1-4)")
  if a1=="1":
    q1=float(input("How Many Cups?"))
    q2=input("Is It Sugar, Flour Or Butter")
    answer=c_g(q1,q2)
    print(answer)
  elif a1=="2":
    q3=float(input("How Many tablespoons?"))
    answer2=ta_te(q3)
    print(answer2)
  elif a1=="3":
    q4=float(input("How Many Grams"))
    q5=input("Is It Sugar, Flour Or Butter")
    answer3=g_c(q4,q5)
    print(answer3)
  elif a1=="4":
    break
  else:
    print("Not An Option")