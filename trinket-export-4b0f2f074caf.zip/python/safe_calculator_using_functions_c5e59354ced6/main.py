
def addition(num_1,num_2):
  return num_1 + num_2
  
def division(num_1,num_2):
  return num_1 / num_2

while True:

  try:
    num_1 = int(input("enter a number:"))
  except ValueError:
    print("enter a vaild number")
    continue
    
  num_2 = int(input("enter a second number:"))
  operat = input("what operation would you like to do?(+,-,*,/)")
  try:
    
    if operat == "+":
      result = addition(num_1,num_2)
      print(result)
      
    elif operat == "/":
      result = division(num_1,num_2)
      print(result)
      
    else:
      raise ValueError
  
  except ZeroDivisionError:
      print("Error: Cannot divide by zero!")
      continue
  except ValueError:
      print("Invalid operator! Please use +, -, *, or /.")
      continue
    