import turtle
pen = turtle.Turtle()
paper = turtle.Screen()

import random

paper.bgcolor("yellow")
pen.speed(100)
for x in range(20):
  pen.penup()
  red = random.randint(0,255)
  yellow = random.randint(0,255)
  green = random.randint(0,255)
  pos1 = random.randint(-150,150)
  pos2 = random.randint(-150,150)
  size = random.randint(20,60)
  num = random.randint(3,10)
  pen.goto(pos1,pos2)
  pen.fillcolor(red,yellow,green)
  pen.begin_fill()
  for x in range(num):
    pen.pendown()
    pen.forward(size)
    pen.right(360/num)
  pen.end_fill()