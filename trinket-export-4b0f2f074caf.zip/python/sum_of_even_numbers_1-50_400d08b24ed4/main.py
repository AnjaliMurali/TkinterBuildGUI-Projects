sum = 0
for i in range(2,51,2):
  print(i)
  sum = sum + i
print("\n\n")
print("The sum is {}".format(sum))