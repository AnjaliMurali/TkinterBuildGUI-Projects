print ("Choose 2 numbers")
Number = int( input("Choose your first number"))
Num = int( input("Choose your second number"))
Sum = Number + Num
print("Addtion"+str(Sum))
Answer = Number - Num
print("Subtraction"+str(Answer))
Equalto= Number * Num
print("Multplication"+str(Equalto))
IsEqual= Number / Num
print("Division"+str(IsEqual))
