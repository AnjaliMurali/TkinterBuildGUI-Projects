planes=[]
o=1
print("--- Choose An Option ---\n1:View List\n2:Add To List\n3:Remove From List\n4:Edit Entr1y\n5:Exit")
while o==1:
  x=input("Select An Option")
  if x=="1":
    print(planes)
  elif x=="2":
    z=input("What Do You Want To Add?")
    planes.append(z)
    print(z+" Successfully Added To List")
  elif x=="3":
    n=input("What Entry Do You Want To Remove?")
    for i in planes:
      if i==n:
        planes.remove(n)
        print(n+" Successfully Removed From List")
      else:
        print("Error. '"+n+"' Is Not In The List")
  elif x=="5":
    print("Goodbye")
    o=2
    l=input("Do You Want To Reopen The App?")
    if l=="yes":
      o=1
      print(planes)