import random

name=input("Please Enter A First And Last Name:")
list_name=name.split()
name_num=len(list_name)
if name_num<2:
  print("Please Enter At Least Two Names")
else:
  while True:
  
    rn=random.randint(0,99)
    fn=list_name[0]
    ln=list_name[-1]
    fnlen=len(fn)
    lnlen=len(ln)
    hfn=int(fnlen/2)
    hln=int(lnlen/2)
    u1=fn+ln+str(rn)
    u2=fn[0:hfn]+ln[hln:]+str(rn)
    u3=str(rn)+fn[0:1]+ln[1:]
    #print(u3)
    un = [u1,u2,u3]
    c = random.choice(un)
    print(c)
    q = input("Do u want another username? - y/n")
    if q == "n":
      break
  
    