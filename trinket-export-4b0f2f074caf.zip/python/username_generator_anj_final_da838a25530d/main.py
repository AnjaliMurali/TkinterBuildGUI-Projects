import random
while True:
  fullname = input("Please enter your full name:")
  nameparts = fullname.split()
  if len(nameparts)<2:
    print("Please enter your first name and last name")
    continue
  else:
    while True:
      first_name = nameparts[0]
      last_name = nameparts[-1]
      username1 = (first_name + last_name)
      #print (username1)
      num_1 = str(random.randint(100,900))
      num_2 = str(random.randint(100,900))
      username2 = num_1 + first_name + num_2 + last_name
      #print (username2)
      username3 = first_name[0:3] + last_name[0:4]
      #print (username3)
      username4 = first_name[-4:-1] + last_name[0:4]
      #print (username4)
      usernames = [username1,username2,username3,username4]
      print(random.choice(usernames))
      c = input("Do you want another username - y/n ?")
      if(c=="n"):
        print("okay..Bye! ")
        break;
  if c == "n":
     break;
  